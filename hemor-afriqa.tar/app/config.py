from decouple import config  # type: ignore # Load values from .env

class Config:
    # Security
    SECRET_KEY = config("SECRET_KEY", default="your-default-secret-key")

    # Database Configuration
    SQLALCHEMY_DATABASE_URI = config("DATABASE_URL")
    SQLALCHEMY_TRACK_MODIFICATIONS = config("SQLALCHEMY_TRACK_MODIFICATIONS", cast=bool, default=False)

    # Image Upload Folder Paths
    COMPANY_UPLOAD_FOLDER = "app/static/images"
    
    # eCommerce Folders
    ECOMMERCE_CATEGORY_UPLOAD_FOLDER = "app/static/images/ecommerce/category"
    ECOMMERCE_PRODUCT_UPLOAD_FOLDER = "app/static/images/ecommerce/products"

    # Event Management Folders
    EVENT_MANAGEMENT_CATEGORY_UPLOAD_FOLDER = "app/static/images/event_management/category"
    EVENT_MANAGEMENT_PRODUCT_UPLOAD_FOLDER = "app/static/images/event_management/events_caption"

    # Email Configuration
    MAIL_SERVER = config("MAIL_SERVER", default="smtp.gmail.com")
    MAIL_PORT = config("MAIL_PORT", cast=int, default=587)
    MAIL_USE_TLS = config("MAIL_USE_TLS", cast=bool, default=True)
    MAIL_USERNAME = config("MAIL_USERNAME", default="hemorafriqa@gmail.com")
    MAIL_PASSWORD = config("MAIL_PASSWORD", default="YourEmailPassword")

    # Company Details
    COMPANY_NAME = config("COMPANY_NAME", default="Hemor Afriqa")
    MOBILE_NUMBER_1 = config("MOBILE_NUMBER_1", default="")
    MOBILE_NUMBER_2 = config("MOBILE_NUMBER_2", default="")
    COMPANY_MAIL = config("COMPANY_MAIL", default="hemorafriqa@gmail.com")
    COMPANY_URL = config("COMPANY_URL", default="https://hemorafriqa.com")
