# utils/date.py for date formatting
from datetime import datetime

def format_date(date):
    return date.strftime("%Y-%m-%d %H:%M:%S")
